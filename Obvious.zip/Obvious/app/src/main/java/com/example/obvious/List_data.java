package com.example.obvious;

class List_data {
    private String name;
    private String imageurl;

    public List_data(String name, String imageurl) {
        this.name = name;
        this.imageurl = imageurl;
    }

    public String getName() {
        return name;
    }

    public String getImageurl() {
        return imageurl;
    }
}